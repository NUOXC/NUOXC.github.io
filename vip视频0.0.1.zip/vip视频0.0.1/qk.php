<h3 class="text-muted" style="color:#F5FFFA" align="center"><strong> 接口可用情况（如失效请联系我） </strong></h3>
<h5 class="text-muted" style="color:#F5FFFA" align="center"><strong> 接口最后验证时间2017年6月9日。本资料仅供参考，最好请自行测试 </strong></h5>
<style type="text/css">
* {
	padding:0;
	margin:0;
}
.wrap {
	width:60%;
	margin:1% auto 0;
}
table {
	border-collapse:collapse;
	border-spacing:0;
	border:1px solid #c0c0c0;
	width:100%;
}
th,td {
	border:1px solid #d0d0d0;
	color:#404040;
	padding:1%;
}
th {
	background-color:#09c;
	font:bold 16px "微软雅黑";
	color:#fff;
}
td {
	font:14px "微软雅黑";
	color:#9932CC;
}
tbody tr {
	background-color:#f0f0f0;
}
tbody tr:hover {
	cursor:pointer;
	background-color:#fafafa;
}
</style>
<div class="wrap">
    <table>
        <thead>
            <tr>
               
                <th>名称</th>
				<th>优酷</th>
                <th>爱奇艺</th>
				<th>腾讯</th>
				<th>乐视</th>
				<th>搜狐</th>
				<th>芒果</th>
				<th>PPTV</th>
				<th>华数</th>
            </tr>
        </thead>
       
            <tr>
                <td>1号接口</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
            </tr>
            <tr>
               <td>2号接口</td>
				<td>✔</td>
				<td>✔</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
            </tr>
            <tr>
                <td>3号接口</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
            </tr>
            <tr>
                <td>4号接口</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
            </tr>
			<tr>
                <td>5号接口</td>
				<td style="color:#B0B0B0" >✖</td>
				<td style="color:#B0B0B0" >✖</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
            </tr>
			<tr>
                <td>6号接口</td>
				<td>✔</td>
				<td>✔</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
            </tr>
			<tr>
                <td>7号接口</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
                <td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
            </tr>
			<tr>
                <td>8号接口</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
            </tr>
			<tr>
                <td>9号接口</td>
				<td style="color:#B0B0B0" >✖</td>
				<td style="color:#B0B0B0" >✖</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td style="color:#B0B0B0" >✖</td>
				<td style="color:#B0B0B0" >✖</td>
            </tr>
			<tr>
                <td>10号接口</td>
				<td style="color:#B0B0B0" >✖</td>
				<td style="color:#B0B0B0" >✖</td>
                <td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
            </tr>
			<tr>
                <td>11号接口</td>
				<td>✔</td>
				<td>✔</td>
                <td style="color:#B0B0B0" >✖</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
				<td>✔</td>
            </tr>
    </table>
</div>

